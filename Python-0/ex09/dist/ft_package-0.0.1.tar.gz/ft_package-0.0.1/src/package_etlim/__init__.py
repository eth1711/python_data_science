from .hello import main

__all__ = ['main']
