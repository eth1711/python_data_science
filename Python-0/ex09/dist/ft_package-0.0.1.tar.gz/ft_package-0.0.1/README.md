# My First Package

This is a simple package I wrote for my Python Data Science Piscine.